exports.handler = async (event, context) => {
    console.log('DEBUG: Basic Node.js Lambda function started');
    
    // Set CORS headers
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Content-Type': 'application/json'
    };
    
    // Handle OPTIONS request (CORS preflight)
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: headers,
            body: ''
        };
    }
    
    // Basic success response
    const responseData = {
        status: 'success',
        message: 'Basic Node.js Lambda function working',
        timestamp: new Date().toISOString()
    };
    
    return {
        statusCode: 200,
        headers: headers,
        body: JSON.stringify(responseData)
    };
};
